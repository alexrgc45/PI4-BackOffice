class AppRouteNames {
  static const String homePath = '/';
  static const String loginPath = '/login';
  static const String mainPath = '/pagina-principal';
  static const String adminPath = '/admin';
  static const String clientPath = '/cliente';

  // Ecrãs do cliente
  static const String clientPedidosPath = '/cliente/pedidos';
  // Recebe o id do trabalho (int) em "arguments" do Navigator.
  static const String clientPedidoDetalhePath = '/cliente/pedidos/detalhe';
  static const String clientNotificacoesPath = '/cliente/notificacoes';
  static const String clientNovoPedidoPath = '/cliente/novo-pedido';
}
